<h1>This is the main post page</h1>
<?php /**PATH /Users/jackj/Desktop/code/Web2024/lft/resources/views/posts/index.blade.php ENDPATH**/ ?>